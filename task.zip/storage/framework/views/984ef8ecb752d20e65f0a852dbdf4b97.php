<?php echo $__env->make('admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--wrapper-->
    <div class="wrapper">
        
        <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <!--start header -->
        <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--end header -->

        <!--start page wrapper -->
        <div class="page-wrapper">

            

                
                 <?php echo $__env->yieldContent('content'); ?>

            


        </div>
        <!--end page wrapper -->


<?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\task\resources\views/admin/admin_master.blade.php ENDPATH**/ ?>