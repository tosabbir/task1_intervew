<?php $__env->startSection('content'); ?>

<div class="page-content">
    <h2>Welcome <?php echo e(Auth()->user()->name); ?></h2>
</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task\resources\views/admin/admin_dashboard.blade.php ENDPATH**/ ?>