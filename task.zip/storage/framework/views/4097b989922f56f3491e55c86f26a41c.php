<!DOCTYPE html>
<html class="no-js" lang="en">

<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

    <!-- Header  -->
    <header class="header-area header-style-1 header-height-2">

        <div class="header-middle header-middle-ptb-1 d-none d-lg-block">
            <div class="container">
                <div class="header-wrap">
                    <div class="logo logo-width-1">
                        <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('frontend')); ?>/assets/imgs/theme/logo.svg"
                                alt="logo" /></a>
                    </div>
                    <div class="header-right">
                        <div class="search-style-2">

                        </div>
                        <div class="header-action-right">
                            <div class="header-action-2">


                                <div class="header-action-icon-2">
                                    <a href="<?php echo e(route('dashboard')); ?>">
                                        <img class="svgInject" alt="Nest"
                                            src="<?php echo e(asset('frontend')); ?>/assets/imgs/theme/icons/icon-user.svg" />
                                    </a>

                                    <?php if(auth()->guard()->check()): ?>

                                    <span class="lable ml-0">Account</span>
                                    <div class="cart-dropdown-wrap cart-dropdown-hm2 account-dropdown">
                                        <ul>
                                            <li>
                                                <a href="<?php echo e(route('dashboard')); ?>"><i class="fi fi-rs-user mr-10"></i>My
                                                    Account</a>
                                            </li>

                                            <li>
                                                <a href="<?php echo e(route('logout')); ?>"><i class="fi fi-rs-sign-out mr-10"></i>Sign
                                                    out</a>
                                            </li>
                                        </ul>
                                    </div>

                                    <?php else: ?>
                                    <a href="<?php echo e(route('login')); ?>"><span class="lable ml-0">Login</span></a>
                                    <a class="me-2px">|</a>
                                    <a href="<?php echo e(route('register')); ?>"><span class="lable ml-0">Register</span></a>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div class="header-bottom header-bottom-bg-color sticky-bar">
            <div class="container">
                <div class="header-wrap header-space-between position-relative">


                    <div class="header-action-icon-2 d-block d-lg-none">
                        <div class="burger-icon burger-icon-white">
                            <span class="burger-icon-top"></span>
                            <span class="burger-icon-mid"></span>
                            <span class="burger-icon-bottom"></span>
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
    </header>

    <!-- End Header  -->


    <div class="mobile-header-active mobile-header-wrapper-style">
        <div class="mobile-header-wrapper-inner">
            <div class="mobile-header-top">
                <div class="mobile-header-logo">
                    <a href="index.html"><img src="<?php echo e(asset('frontend')); ?>/assets/imgs/theme/logo.svg"
                            alt="logo" /></a>
                </div>
                <div class="mobile-menu-close close-style-wrap close-style-position-inherit">
                    <button class="close-style search-close">
                        <i class="icon-top"></i>
                        <i class="icon-bottom"></i>
                    </button>
                </div>
            </div>
            <div class="mobile-header-content-area">

                <div class="mobile-menu-wrap mobile-header-border">
                    <!-- mobile menu start -->
                    <nav>
                        <ul class="mobile-menu font-heading">

                            <li class="menu-item-has-children">
                                <a href="#">Account</a>
                                <ul class="dropdown">

                                    <li><a href="page-account.html">My Account</a></li>
                                    <li><a href="page-login.html">Login</a></li>
                                    <li><a href="page-register.html">Register</a></li>

                                </ul>
                            </li>

                        </ul>
                    </nav>
                    <!-- mobile menu end -->
                </div>

            </div>
        </div>
    </div>
    <!--End header-->

    <main class="main">
<?php /**PATH C:\xampp\htdocs\task\resources\views/includes/header.blade.php ENDPATH**/ ?>