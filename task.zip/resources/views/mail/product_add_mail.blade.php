<h3>New Product Added</h3>

<p>Name: {{$name}}</p>
<p>Price: {{$price}}</p>
<p>Category: {{$category}}</p> <br>
<p>Image</p>

